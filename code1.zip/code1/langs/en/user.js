export default {
    "title" : "login! => {{x}}"
};
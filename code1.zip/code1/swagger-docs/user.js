export default {
    "/user/login": {
      "post": {
        "tags": [
          "Users"
        ],
        "summary": "User Login",
        "description": "User Login",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "email",
            "in": "formData",
            "description": "email",
            "required": false,
            "type": "string"
          },
          {
            "name": "password",
            "in": "formData",
            "description": "password",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/profile": {
      "get": {
        "tags": [
          "Users"
        ],
        "summary": "User Get Profile",
        "description": "User Get Profile",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/refresh-token": {
      "post": {
        "tags": [
          "Users"
        ],
        "summary": "User Refresh Token",
        "description": "User Refresh Token",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "access_token",
            "in": "formData",
            "description": "access_token",
            "required": false,
            "type": "string"
          },
          {
            "name": "refresh_token",
            "in": "formData",
            "description": "refresh_token",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/logout": {
      "post": {
        "tags": [
          "Users"
        ],
        "summary": "User Logout",
        "description": "User Logout",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/upload-avatar": {
      "put": {
        "tags": [
          "Users"
        ],
        "summary": "Upload User Avatar",
        "description": "Upload User Avatar",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "avatar",
            "in": "formData",
            "description": "avatar",
            "required": false,
            "type": "file"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/remove-avatar": {
      "delete": {
        "tags": [
          "Users"
        ],
        "summary": "Remove User Avatar",
        "description": "Remove User Avatar",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/update-profile": {
      "put": {
        "tags": [
          "Users"
        ],
        "summary": "Update User Profile",
        "description": "Update User Profile",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "first_name",
            "in": "formData",
            "description": "first_name",
            "required": false,
            "type": "string"
          },
          {
            "name": "last_name",
            "in": "formData",
            "description": "last_name",
            "required": false,
            "type": "string"
          },
          {
            "name": "email",
            "in": "formData",
            "description": "email",
            "required": false,
            "type": "string"
          },
          {
            "name": "current_password",
            "in": "formData",
            "description": "current password",
            "required": false,
            "type": "string"
          },
          {
            "name": "new_password",
            "in": "formData",
            "description": "new password",
            "required": false,
            "type": "string"
          },
          {
            "name": "confirm_new_password",
            "in": "formData",
            "description": "confirm new password",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/user/check-token": {
      "post": {
        "tags": [
          "Users"
        ],
        "summary": "check user token ",
        "description": "check user token",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
};

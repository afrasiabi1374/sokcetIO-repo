import BaseController from "../core/BaseController.js";
import {validationResult,body} from 'express-validator';
import translate from "../core/translate.js";
import crypto from './../core/crypto.js';
import http from './../core/http.js';
import mailSend from './../core/mail.js';
import {isFile,unlink,fileExists} from './../core/fs.js';
import {allowImageFileUpload,fileNameGenerator,toByte} from './../core/uploader.js';
import {random,stringify,log, getEnv,getPath} from './../core/utils.js';
import datetime from './../core/datetime.js';
import AdminModel from './../models/admin.js';
import Token from './../core/token.js';
import { Redis,Emitter,io } from "./../global.js";
import ProductModel from './../models/product.js';

export default class UserController extends BaseController
{
    #url =  getEnv('APP_URL') + 'user/';

    constructor()
    {
        super();
        this.model = new AdminModel();
        this.proModel = new ProductModel();
    }
    


    async login(req,res){
        try{
            
            Emitter.emit('login',{"a":"aaaa"});
            Emitter.emit('register',{"do":"upload!"});
            io.io.emit('onLogin',{"salam":"xxx"});
            const email = this.safeString(this.input(req.body.email));
            const password = this.input(req.body.password);
            const result = await this.#loginValidation(req);
            if(!result.isEmpty())
            {
                return res.json(result?.errors[0]?.msg);
            }  
            const resultLogin = await this.model.login(email,password);
            if(resultLogin?._id)
            {
                const resultToken = await Token.generate(resultLogin?._id,resultLogin?.status);
                if(typeof resultToken === 'string')
                {
                    return res.json({"code":5,"msg":"token generate error!"});
                }
                else
                {
                    const userData = await this.model.getUserData(resultLogin);
                    const data = {
                        "user_info" : userData,
                        "access_token" : resultToken?.access_token,
                        "refresh_token" : resultToken?.refresh_token,
                    };
                    return res.json({"code":0,"msg":translate.t("user.login_success"),"data":data});    
                }
            }
            else
            {
                switch(resultLogin)
                {
                    case -1:
                        return res.json({"code":4,"msg":translate.t("user.login_failed")});
                    break;
                    case -2:
                        return res.json({"code":5,"msg":translate.t("user.login_account_disabled")});
                    break;     
                    case -3:
                        return res.json({"code":6,"msg":translate.t("user.login_account_blocked")});
                    break;         
                }
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    async #loginValidation(req){
        await body('email').not().isEmpty().withMessage({"code":1,"msg":translate.t("user.validation_email_required")})
            .isEmail().withMessage({"code":2,"msg":translate.t("user.validation_email_email")})
            .run(req);
        await body('password').not().isEmpty().withMessage({"code":3,"msg":translate.t("user.validation_password_required")}).run(req);
        return validationResult(req);   
    }


    async logout(req,res){
        try{
            const key_access_token = getEnv('ACCESS_TOKEN_PREFIX') + req?.userToken?.access_token;
            const key_refresh_token = getEnv('REFRESH_TOKEN_PREFIX') + req?.userToken?.refresh_token;
            await Redis.del(key_access_token);
            await Redis.del(key_refresh_token);
            return res.json({"code":0,"msg":"logout success!","is_auth":0});    
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async profile(req,res){
        try{
            const userInfo = await this.model.getProfile(req?.userToken?.user_id);
            const userData = await this.model.getUserData(userInfo);
            return res.json({"code":0,"msg":"success!","data":userData,"is_auth":0});    
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }



    async refreshToken(req,res){
        try{
            const access_token = this.safeString(this.input(req.body.access_token));
            const refresh_token = this.safeString(this.input(req.body.refresh_token));
            const key_refresh_token = getEnv('REFRESH_TOKEN_PREFIX') + refresh_token;
            const key_access_token = getEnv('ACCESS_TOKEN_PREFIX') + access_token;
            const data = await Redis.getHash(key_refresh_token);
            if(data?.refresh_token && access_token === data?.access_token)
            {
                await Redis.del(key_access_token);
                await Redis.del(key_refresh_token);
                const resultToken = await Token.generate(data?.user_id,data?.status);
                if(typeof resultToken === 'string')
                {
                    return res.json({"code":2,"msg":"token generate error!"});
                }
                else
                {
                    const userInfo = await this.model.getProfile(data?.user_id);
                    const userData = await this.model.getUserData(userInfo);
                    const data2 = {
                        "access_token" : resultToken?.access_token,
                        "refresh_token" : resultToken?.refresh_token,
                        "user_info" : userData,
                    }
                    return res.json({"code":0,"msg":"success!","data":data2});    
                }
            }
            else
            {
                return res.json({"code":1,"msg":"refresh token is invalid!"});    
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    async #saveProfileValidation(req){
        await body('first_name').not().isEmpty().withMessage({"code":1,"msg":"please enter first name","is_auth":0}).run(req);
        await body('last_name').not().isEmpty().withMessage({"code":2,"msg":"please enter last name","is_auth":0}).run(req);
        const email = this.input(req.body.email);
        if(email !== "")
            await body('email').isEmail().withMessage({"code":3,"msg":"please enter valid email","is_auth":0}).run(req);
        await body(['current_password','new_password','confirm_new_password']).custom(() => {
            const current_password = this.input(req.body.current_password);
            const new_password = this.input(req.body.new_password);
            const confirm_new_password = this.input(req.body.confirm_new_password);
            if(current_password !== "")
            {
                if(new_password === "")
                {
                    throw new Error(4);
                }
                if(confirm_new_password === "")
                {
                    throw new Error(5);
                }
                if(new_password !== confirm_new_password)
                {
                    throw new Error(6);
                }
            }
            return true;
        }).run(req);
        return validationResult(req);   
    }

    async uploadAvatar(req,res){
        try{
            const userInfo = await this.model.getProfile(req?.userToken?.user_id);
            let currentAvatar = userInfo?.avatar ?? '';
            if(currentAvatar === "")
            {          
                if(req?.files?.avatar)
                {
                    if(req.files.avatar.size <= toByte(5,'MB'))
                    {
                        const ext = allowImageFileUpload(req.files.avatar.mimetype);
                        if(ext !== '')
                        {
                             const fileName = 'avatars/' + fileNameGenerator('avatar',ext);
                             const path = getPath() + 'media/' + fileName;
                             await req.files.avatar.mv(path);
                             const urlAvatar =  getEnv('API_URL') + fileName;
                             await this.model.updateAvatar(req?.userToken?.user_id,fileName);
                             return res.json({"code":0,"msg":"success","is_auth":0,"data":urlAvatar});    
                        }
                        else
                        {
                            return res.json({"code":4,"msg":translate.t('user.upload_avatar_not_allow'),"is_auth":0});    
                        }
                    }
                    else
                    {
                        return res.json({"code":3,"msg":translate.t('user.upload_avatar_max_size'),"is_auth":0});    
                    }
                }
                else
                {
                    return res.json({"code":2,"msg":translate.t('user.upload_avatar_not_send_file'),"is_auth":0});    
                }
            }
            else
            {
                return res.json({"code":1,"msg":translate.t('user.upload_avatar_alredy'),"is_auth":0});    
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    async removeAvatar(req,res){
        try{
            const userInfo = await this.model.getProfile(req?.userToken?.user_id);
            let currentAvatar = userInfo?.avatar ?? '';
            if(currentAvatar !== "")
            {          
                const path = getPath() + 'media/' + currentAvatar;
                if(fileExists(path))
                {
                   unlink(path);
                }
                await this.model.deleteAvatar(req?.userToken?.user_id);
            }
            return res.json({"code":0,"msg":"success","is_auth":0});    
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async updateProfile(req,res){
        try{
            const result = await this.#saveProfileValidation(req);
            if(!result.isEmpty())
            {
                let error = {};
                switch(result?.errors[0]?.msg)
                {
                    case '4':
                        error = {"code":4,"msg":"please enter new_password","is_auth":0};
                    break;
                    case '5':
                        error = {"code":5,"msg":"please enter confirm_new_password","is_auth":0};
                    break;
                    case '6':
                        error = {"code":6,"msg":"confirm_new_password is not match!","is_auth":0};
                    break;
                    default:
                        error = result?.errors[0]?.msg;
                    break;
            
                }
                return res.json(error);
            }
            const first_name = this.safeString(this.input(req.body.first_name));
            const last_name = this.safeString(this.input(req.body.last_name));
            const email = this.safeString(this.input(req.body.email));
            const current_password = this.input(req.body.current_password);
            const new_password = this.input(req.body.new_password);
            const confirm_new_password = this.input(req.body.confirm_new_password);
            const resultSave = await this.model.saveProfile(req?.userToken?.user_id,first_name
                ,last_name,email,current_password,new_password,confirm_new_password);
            switch(resultSave)
            {
                case -1:
                    return res.json({"code":7,"msg":"email is already!","is_auth":0});
                break;
                case -2:
                    return res.json({"code":8,"msg":"current password is not correct!","is_auth":0});
                break;
                case 1:
                    const userInfo = await this.model.getProfile(req?.userToken?.user_id);
                    const userData = await this.model.getUserData(userInfo);
                    return res.json({"code":0,"msg":"success!","data":userData,"is_auth":0});            
                break;                        
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async checkToken(req,res){
        try{
            const userInfo = await this.model.getProfile(req?.userToken?.user_id);
            const userData = await this.model.getUserData(userInfo);
            return res.json({"code":0,"msg":"success!","data":userData,"is_auth":0});    
        }
        catch(e){
            return super.toError(e,req,res);
        }

    }


}
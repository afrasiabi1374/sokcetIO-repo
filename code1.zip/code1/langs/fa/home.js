export default {
    "page_title" : "داشبورد",
};
import user from './user.js';
export default {
    "user" : user,
    "test" : "test ::::  {{t}}",
};
import BaseController from "../core/BaseController.js";
import {validationResult,body} from 'express-validator';
import translate from "../core/translate.js";
import crypto from './../core/crypto.js';
import {isFile,unlink,fileExists} from './../core/fs.js';
import {allowImageFileUpload,fileNameGenerator,toByte} from './../core/uploader.js';
import {random,stringify,log, getEnv,getPath} from './../core/utils.js';
import datetime from './../core/datetime.js';
import CategoryModel from './../models/category.js';

export default class CategoryController extends BaseController
{
    #url =  getEnv('APP_URL') + 'category/';

    constructor()
    {
        super();
        this.model = new CategoryModel();
    }
    
    async add(req,res){
        try{
            const result = await this.#validation(req);
            if(!result.isEmpty())
            {
                if(result?.errors[0]?.msg === "6")
                {
                    return res.json({"code":6,"msg":"slug is invalid a-z 0-9 and -","is_auth":0});
                }
                else
                {
                    return res.json(result?.errors[0]?.msg);
                }
            }  
            const parent_id = this.safeString(this.input(req.body.parent_id));
            const title = this.safeString(this.input(req.body.title));
            const title_seo = this.safeString(this.input(req.body.title_seo));
            const description_seo = this.safeString(this.input(req.body.description_seo));
            const slug = this.safeString(this.input(req.body.slug));
            let status = this.safeString(this.input(req.body.status));
            status = (status === "1") ? true : false;
            if(parent_id !== "0")
            {
                if(!this.toObjectId(parent_id))
                {
                    return res.json({"code":7,"msg":"parent_id is invalid value!","is_auth":0});    
                }
            }

            const resultAdd = await this.model.add(parent_id,title,title_seo,description_seo,slug,status);
            if(typeof resultAdd === 'number')
            {
                switch(resultAdd)
                {
                    case -1:
                        return res.json({"code":9,"msg":"title is already!","is_auth":0});
                    break;
                    case -2:
                        return res.json({"code":10,"msg":"slug is alreday","is_auth":0});
                    break;
                }
            }
            else if(resultAdd?._id)
            {
                return res.json({"code":0,"msg":"success add category!","is_auth":0});    
            }
            else
                return res.json({"code":8,"msg":"error please try again","is_auth":0});

        }
        catch(e){
            return super.toError(e,req,res);
        }

    }


    async #validation(req){
        await body('parent_id').not().isEmpty().withMessage({"code":1,"msg":"parent_id is empty","is_auth":0}).run(req);
        await body('title').not().isEmpty().withMessage({"code":2,"msg":"title is empty","is_auth":0}).run(req);
        await body('title_seo').not().isEmpty().withMessage({"code":3,"msg":"title_seo is empty","is_auth":0}).run(req);
        await body('description_seo').not().isEmpty().withMessage({"code":4,"msg":"description_seo is empty","is_auth":0}).run(req);
        await body('slug').not().isEmpty().withMessage({"code":5,"msg":"slug is empty","is_auth":0}).custom(() => {
            const slug = this.input(req.body.slug);
            const check = /^[a-z0-9-]+$/.test( slug );
            if(check)
                return true;
            else
                throw new Error("6");
        }).run(req);
        return validationResult(req);   
    }



    #getParams(req){
        try{
            let parent_id = this.safeString(this.input(req.query.parent_id));
            parent_id = (parent_id === "0") ? 0 : this.toObjectId(parent_id,true); 
            const title = this.safeString(this.input(req.query.title));
            const params = {
                parent_id,title
            };
            const paramsQuery = this.toQuery(params);
            return {
                "params" : params,
                "params_query" : paramsQuery,
            }    
        }
        catch(e){
            return {
                "params" : {},
                "params_query" : '',
            }    
        }
    }

    async index(req,res){
        try{
            const sortFields = ['_id','parent_id','title','last_edit_date_time','status'];
            const {page,sort_field,sort_type,limit} = this.handlePagination(req,sortFields);
            const {params,params_query} = this.#getParams(req);
            const pagination = await this.model.pagination(limit,page,sort_field,sort_type,params?.parent_id,params?.title);
            const data = {
                "pagination" : pagination,
                "page" : page,
            }
            return res.json({"code":0,"is_auth":0,"data":data});
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async view(req,res){
        try{
            const id = this.toObjectId(this.input(req.params.id),true);
            if(id === '')
            {
                return res.json({"code":1,"is_auth":0,"msg":"id is invalid!"});
            }
            const data = await this.model.getRow(id);
            if(data?._id)
                return res.json({"code":0,"is_auth":0,"data":data});
            else
                return res.json({"code":2,"is_auth":0,"msg":"row not found!"});
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    async changeStatus(req,res){
        try{
            const id = this.toObjectId(this.input(req.params.id),true);
            if(id === '')
            {
                return res.json({"code":1,"is_auth":0,"msg":"id is invalid!"});
            }
            const data = await this.model.getRow(id);
            if(data?._id)
            {
                let status = this.safeString(this.input(req.body.status));
                status = (status === "1") ? true : false;
                await this.model.changeStatus(id,status);
                return res.json({"code":0,"is_auth":0,"msg":"success!"});
            }
            else
                return res.json({"code":2,"is_auth":0,"msg":"row not found!"});
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    async remove(req,res){
        try{
            const id = this.toObjectId(this.input(req.params.id),true);
            if(id === '')
            {
                return res.json({"code":1,"is_auth":0,"msg":"id is invalid!"});
            }
            const data = await this.model.getRow(id);
            if(data?._id)
            {
                const resultDelete =  await this.model.deleteRow(id);
                if(resultDelete === 1)
                   return res.json({"code":0,"is_auth":0,"msg":"delete success!"});
                else
                    return res.json({"code":3,"is_auth":0,"msg":"can not delete have children!"});
            }
            else
                return res.json({"code":2,"is_auth":0,"msg":"row not found!"});
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async update(req,res){
        try{
            const id = this.toObjectId(this.input(req.params.id),true);
            if(id === '')
            {
                return res.json({"code":7,"is_auth":0,"msg":"id is invalid!"});
            }
            const data = await this.model.getRow(id);
            if(data?._id)
            {
                const result = await this.#validation(req);
                if(!result.isEmpty())
                {
                    if(result?.errors[0]?.msg === "6")
                    {
                        return res.json({"code":6,"msg":"slug is invalid a-z 0-9 and -","is_auth":0});
                    }
                    else
                    {
                        return res.json(result?.errors[0]?.msg);
                    }
                }      
                const parent_id = this.safeString(this.input(req.body.parent_id));
                const title = this.safeString(this.input(req.body.title));
                const title_seo = this.safeString(this.input(req.body.title_seo));
                const description_seo = this.safeString(this.input(req.body.description_seo));
                const slug = this.safeString(this.input(req.body.slug));
                let status = this.safeString(this.input(req.body.status));
                status = (status === "1") ? true : false;
                if(parent_id !== "0")
                {
                    if(!this.toObjectId(parent_id))
                    {
                        return res.json({"code":9,"msg":"parent_id is invalid value!","is_auth":0});    
                    }
                }
                const resultSave = await this.model.save(id,parent_id,title,title_seo,description_seo,slug,status);
                if(resultSave === 1)
                    return res.json({"code":0,"is_auth":0,"msg":"success!"});
                else
                {
                    switch(resultSave)
                    {
                        case -1:
                            return res.json({"code":10,"msg":"slug is already!","is_auth":0});
                        break;
                        case -2:
                            return res.json({"code":11,"msg":"title is alreday","is_auth":0});
                        break;
                        default:
                            return res.json({"code":13,"msg":"error please try again!","is_auth":0});
                        break;
                    }    
                }
            }
            else
                return res.json({"code":8,"is_auth":0,"msg":"row not found!"});
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


   





}

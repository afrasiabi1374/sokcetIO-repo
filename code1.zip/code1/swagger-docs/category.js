export default {
    "/category/add": {
      "post": {
        "tags": [
          "Category"
        ],
        "summary": "Add New Category",
        "description": "Add New Category",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "parent_id",
            "in": "formData",
            "description": "parent_id",
            "required": false,
            "type": "string"
          },
          {
            "name": "title",
            "in": "formData",
            "description": "title",
            "required": false,
            "type": "string"
          },
          {
            "name": "title_seo",
            "in": "formData",
            "description": "title_seo",
            "required": false,
            "type": "string"
          },
          {
            "name": "description_seo",
            "in": "formData",
            "description": "description_seo",
            "required": false,
            "type": "string"
          },
          {
            "name": "slug",
            "in": "formData",
            "description": "slug",
            "required": false,
            "type": "string"
          },
          {
            "name": "status",
            "in": "formData",
            "description": "status",
            "required": false,
            "enum": [
              "1",
              "0",
            ],          
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/category/": {
      "get": {
        "tags": [
          "Category"
        ],
        "summary": "List Category",
        "description": "List Category",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "page",
            "in": "query",
            "description": "page",
            "required": false,
            "type": "string"
          },
          {
            "name": "sort_type",
            "in": "query",
            "description": "sort_type",
            "required": false,
            "type": "string"
          },
          {
            "name": "sort_field",
            "in": "query",
            "description": "sort_field",
            "required": false,
            "type": "string"
          },
          {
            "name": "limit",
            "in": "query",
            "description": "limit",
            "required": false,
            "type": "string"
          },
          {
            "name": "parent_id",
            "in": "query",
            "description": "parent_id",
            "required": false,
            "type": "string"
          },
          {
            "name": "title",
            "in": "query",
            "description": "title",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/category/view/{id}": {
      "get": {
        "tags": [
          "Category"
        ],
        "summary": "get Category By id",
        "description": "get Category By id",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "id",
            "in": "path",
            "description": "id",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/category/change-status/{id}": {
      "put": {
        "tags": [
          "Category"
        ],
        "summary": "Change Status Category By id",
        "description": "Change Status Category By id",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "id",
            "in": "path",
            "description": "id",
            "required": false,
            "type": "string"
          },
          {
            "name": "status",
            "in": "formData",
            "description": "status",
            "enum": [
              "1",
              "0",
            ],          
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/category/remove/{id}": {
      "delete": {
        "tags": [
          "Category"
        ],
        "summary": "Delete Category By id",
        "description": "Delete Category By id",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "id",
            "in": "path",
            "description": "id",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
    "/category/update/{id}": {
      "put": {
        "tags": [
          "Category"
        ],
        "summary": "Update Category",
        "description": "Update Category",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "x-token",
            "in": "header",
            "description": "x-token",
            "required": false,
            "type": "string"
          },
          {
            "name": "id",
            "in": "path",
            "description": "id",
            "required": false,
            "type": "string"
          },
          {
            "name": "parent_id",
            "in": "formData",
            "description": "parent_id",
            "required": false,
            "type": "string"
          },
          {
            "name": "title",
            "in": "formData",
            "description": "title",
            "required": false,
            "type": "string"
          },
          {
            "name": "title_seo",
            "in": "formData",
            "description": "title_seo",
            "required": false,
            "type": "string"
          },
          {
            "name": "description_seo",
            "in": "formData",
            "description": "description_seo",
            "required": false,
            "type": "string"
          },
          {
            "name": "slug",
            "in": "formData",
            "description": "slug",
            "required": false,
            "type": "string"
          },
          {
            "name": "status",
            "in": "formData",
            "description": "status",
            "required": false,
            "enum": [
              "1",
              "0",
            ],          
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
};

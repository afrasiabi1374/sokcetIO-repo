$(document).ready(function () {

    if(localStorage.getItem('email'))
    {
        $('#user-email').html(localStorage.getItem('email'));
        $('#result-login').html('');
        $('#login').hide();
        $('#chat').show();
    }

    const socket = io("http://0.0.0.0:3001");
    socket.on("connect", () => {
        console.log('connect'); 
    });
      
    socket.on("disconnect", () => {
        console.log('disconnect');
    });
    socket.on("connect_error", (error) => {
        console.log('error');
        console.log(error);
    });     

    socket.on("resultAuthUser", (data) => {
        console.log('resultAuthUser is call');
        console.log(data);
        if(data?.is_auth)
        {
            localStorage.setItem('token',data?.token);
            localStorage.setItem('email',data?.email);
            $('#user-email').html(data?.email);
            $('#result-login').html('');
            $('#login').hide();
            $('#chat').show();
        }
        else
        {
            $('#result-login').html('<div class="alert alert-danger text-center">' +  data.msg  + '</div>');
        }
    });


    $('#btn-login').click(function(){
        console.log('login!');
        var email = $('#email').val();
        var password = $('#password').val();
        socket.emit('authUser',{"email":email,"password":password});
    });

    $('#btn-send').click(function(){
        console.log('send!');
        var msg = $('#msg').val();
        if(msg.trim() != "")
        {
            socket.emit('userSendMessage',{"msg":msg,'token':localStorage.getItem('token')});
        }
    });


});
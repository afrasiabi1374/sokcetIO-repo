import { Router } from "express";
import {log} from '../core/utils.js';
import CategoryController from "../controllers/CategoryController.js";
import AuthMiddleware from '../middlewares/auth.js';
import RateLimitMiddleware from '../middlewares/ratelimit.js';
const controller = new CategoryController();
const route = Router();
try{
    route.post('/add',new AuthMiddleware().isAuth,controller.add);
    route.get('/',new AuthMiddleware().isAuth,controller.index);
    route.get('/view/:id',new AuthMiddleware().isAuth,controller.view);
    route.put('/change-status/:id',new AuthMiddleware().isAuth,controller.changeStatus);
    route.delete('/remove/:id',new AuthMiddleware().isAuth,controller.remove);
    route.put('/update/:id',new AuthMiddleware().isAuth,controller.update);
}
catch(e){
    route.use(controller.errorHandling(e.toString()));
}

export default route;


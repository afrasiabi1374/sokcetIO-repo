import {Schema} from 'mongoose';

export default new Schema({
    title : {
        type : String,
        required : true,
    },
    price : {
        type : Number
    },
    color : {
        type : Array
    },
    attr : {
        width : {
            type : Number
        },
        height : {
            type : Number
        },
        weight : {
            type : Number
        },
        code : {
            type : String
        }
    },
    comments : [
        {
            user_id : {
                type : Number
            },
            date_time : {
                type : Date
            },
            message : {
                type : String,
            },
            status : {
                type: Boolean
            }
        }
    ]


});
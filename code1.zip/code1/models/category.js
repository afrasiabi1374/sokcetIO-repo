import {MongoDB} from '../global.js';
import CategorySchema from './../schemas/category.js';
import {log,toObjectId,getEnv} from './../core/utils.js';
import datetime from './../core/datetime.js';
import crypto from './../core/crypto.js';

export default class CategoryModel
{
    constructor(){
        this.model = MongoDB.db.model('category', CategorySchema);
    }

    async add(parent_id,title,title_seo,description_seo,slug,status){
        parent_id = (parent_id === "0") ? null : parent_id;
        const last_edit_date_time = datetime.toString();
        const isDupTitle = await this.#checkTitle(parent_id,title);
        if(isDupTitle > 0)
        {
            return -1;//title is already
        }
        const isDupSlug = await this.#checkSlug(slug);
        if(isDupSlug > 0)
        {
            return -2;//slug is already
        }
        const row = new this.model({
            parent_id,title,title_seo,description_seo,slug,status,last_edit_date_time
        });
        return await row.save();
    }


    async #checkTitle(parent_id,title){
        return await this.model.findOne(
            {
                "parent_id":parent_id,
                "title":{$regex: title, "$options": "i"}
            }
        ).countDocuments();
    }


    async #checkSlug(slug){
        return await this.model.findOne({"slug":slug}).countDocuments();
    }

    async getMainCategoryList(){
        return await this.model.find({"parent_id":null}).sort([['title',1]]);
    }


    async pagination(limit,page,sortField,sortType,parent_id,title){
        const where = {};

        if(parent_id !== '')
        {
            parent_id = (parent_id === 0) ? null : parent_id;
            where['parent_id'] = parent_id;
        }

        if(title !== '')
        {
            where['title'] = {$regex: '.*' + title + '.*', "$options": "i"};
        }

        const ROWS_PRE_PAGE = limit;
        const skip = ROWS_PRE_PAGE * page - ROWS_PRE_PAGE;
        const totalRows = await this.model.findOne(where).countDocuments();
        const totalPage = Math.ceil(totalRows / ROWS_PRE_PAGE);
        const rows =  await this.model.find(where).sort([[sortField,sortType]]).populate('parent_id',{title:1})
        .skip(skip)
        .limit(ROWS_PRE_PAGE);
        return {
            rows,totalRows,totalPage
        };

    }


    async changeStatus(status_id,status_value){
        const last_edit_date_time = datetime.toString();
        const data = {
            "status" : status_value,
            "last_edit_date_time" : last_edit_date_time,
        };
        
        await this.model.updateOne({"_id":status_id},{
            "$set" : data 
        });

        return 1;
    }

    async getRow(id){
        return await this.model.findOne({"_id":id}).populate('parent_id',{title:1});
    }

    async save(id,parent_id,title,title_seo,description_seo,slug,status){
        const currentRow = await this.getRow(id);    
        parent_id = (parent_id === "0") ? null : parent_id;
        const last_edit_date_time = datetime.toString();
        const data = {
            "status" : status,
            "title_seo" : title_seo,
            "description_seo" : description_seo,
            "last_edit_date_time" : last_edit_date_time,
        };


        if(currentRow['slug'] !== slug)
        {
            const isDupSlug = await this.#checkSlug(slug);
            if(isDupSlug > 0)
            {
                return -1;//slug is already
            }
            else
            {
                data['slug'] = slug;
            }    
        }


        if(currentRow['title'] !== title)
        {
            const isDup = await this.#checkTitle(parent_id,title);
            if(isDup > 0)
            {
                return -2;//title is already
            }
            else
            {
                data['title'] = title;
            }    
        }

        if(currentRow['parent_id'] != parent_id)
        {
            const isDup = await this.#checkTitle(parent_id,title);
            if(isDup > 0)
            {
                return -2;//parent is already
            }
            else
            {
                data['parent_id'] = parent_id;
            }    
        }


        const result = await this.model.updateOne({"_id":id},{
            "$set" : data 
        });

        
        if(result?.modifiedCount > 0)
            return 1;
        else
            return 0;

    }

    async deleteRow(id){
        if(!toObjectId(id))
        {
            return 0;
        }
        const currentRow = await this.getRow(id);
        if(!currentRow)
            return 0;
        
        if(currentRow['parent_id'] === null)
        {
            const countChilds = await this.model.findOne({"parent_id":id}).countDocuments();
            if(countChilds === 0)
            {
                await this.model.deleteOne({"_id":id});
                return 1;    
            }
            else
                return 0;
        }
        else
        {   
            await this.model.deleteOne({"_id":id});
            return 1;

        }
    }


}



